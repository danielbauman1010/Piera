import Foundation

protocol FiltersBasedOnTime{
    
}
