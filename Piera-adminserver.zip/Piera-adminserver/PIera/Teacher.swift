import Foundation

class Teacher: Person{
    
    init(name: String, password: String, email: String, university: String, id: Int){
        super.init(name: name, password: password, email: email, university: university, id: id)
    }
}
